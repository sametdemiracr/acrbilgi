<?php
/**
 * ACR Bilgi — form gönderim uç noktası
 * Site kök dizininde durur. Formlar buraya POST eder, JSON döner.
 */
declare(strict_types=1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

/** JSON yanıt döndürüp çıkar. */
function yanit(bool $ok, string $mesaj, int $kod = 200): void
{
    http_response_code($kod);
    echo json_encode(['ok' => $ok, 'mesaj' => $mesaj], JSON_UNESCAPED_UNICODE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    yanit(false, 'Geçersiz istek.', 405);
}

$cfg = require __DIR__ . '/php/config.php';
require __DIR__ . '/php/PHPMailer/Exception.php';
require __DIR__ . '/php/PHPMailer/PHPMailer.php';
require __DIR__ . '/php/PHPMailer/SMTP.php';

/** Başlık enjeksiyonuna karşı temizle. */
function temiz(string $s, int $limit = 300): string
{
    $s = str_replace(["\r", "\n", "%0a", "%0d"], ' ', $s);
    $s = trim(strip_tags($s));
    return mb_substr($s, 0, $limit);
}

function alan(string $ad, int $limit = 300): string
{
    return isset($_POST[$ad]) && is_string($_POST[$ad]) ? temiz($_POST[$ad], $limit) : '';
}

// --- 1. Bal küpü: gizli alan doluysa bot demektir, sessizce başarılı dön ---
if (alan('website') !== '' || alan('firma_adi_2') !== '') {
    yanit(true, 'Mesajınız alındı.');
}

// --- 2. Zorunlu alanlar ---
$ad      = alan('ad', 120);
$eposta  = alan('eposta', 160);
$mesaj   = isset($_POST['mesaj']) && is_string($_POST['mesaj'])
           ? trim(strip_tags($_POST['mesaj'])) : '';
$mesaj   = mb_substr($mesaj, 0, 5000);

if ($ad === '' || $eposta === '') {
    yanit(false, 'Lütfen ad soyad ve e-posta alanlarını doldurun.', 422);
}
if (!filter_var($eposta, FILTER_VALIDATE_EMAIL)) {
    yanit(false, 'E-posta adresi geçerli görünmüyor.', 422);
}

// --- 3. Saatlik IP limiti ---
$ip  = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$log = $cfg['log_dosyasi'];
$simdi = time();
$sayac = 0;
if (is_readable($log)) {
    foreach (array_slice(file($log, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES), -400) as $satir) {
        $p = explode("\t", $satir);
        if (count($p) >= 2 && $p[1] === $ip && (int) $p[0] > $simdi - 3600) {
            $sayac++;
        }
    }
}
if ($sayac >= (int) $cfg['saatlik_limit']) {
    yanit(false, 'Kısa sürede çok fazla gönderim yapıldı. Lütfen bir süre sonra tekrar deneyin '
        . 'ya da doğrudan ' . $cfg['telefon'] . ' numarasından bize ulaşın.', 429);
}

// --- 4. Diğer alanlar ---
$tip     = alan('form_tipi', 60) ?: 'İletişim';
$firma   = alan('firma', 160);
$telefon = alan('telefon', 60);
$kullanici = alan('kullanici', 60);
$konu    = alan('konu', 160);
$paket   = alan('paket', 400);
$tutar   = alan('tutar', 60);

$satirlar = array_filter([
    'Form'             => $tip,
    'Ad soyad'         => $ad,
    'Firma'            => $firma,
    'Telefon'          => $telefon,
    'E-posta'          => $eposta,
    'Kullanıcı sayısı' => $kullanici,
    'İlgilendiği konu' => $konu,
    'Seçilen paket'    => $paket,
    'Tahmini tutar'    => $tutar,
], static fn($v) => $v !== '');

$duz = '';
$html = '';
foreach ($satirlar as $k => $v) {
    $duz .= $k . ': ' . $v . "\n";
    $html .= '<tr><td style="padding:6px 14px 6px 0;color:#5A6472;white-space:nowrap">'
        . htmlspecialchars($k, ENT_QUOTES, 'UTF-8') . '</td>'
        . '<td style="padding:6px 0;color:#0B1220"><b>'
        . htmlspecialchars($v, ENT_QUOTES, 'UTF-8') . '</b></td></tr>';
}
if ($mesaj !== '') {
    $duz .= "\nMesaj:\n" . $mesaj . "\n";
}
$duz .= "\n---\nIP: $ip\nTarih: " . date('d.m.Y H:i');

// --- 5. Gönder ---
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = $cfg['smtp_host'];
    $mail->Port       = (int) $cfg['smtp_port'];
    $mail->SMTPAuth   = true;
    $mail->Username   = $cfg['smtp_user'];
    $mail->Password   = $cfg['smtp_pass'];
    $mail->SMTPSecure = $cfg['smtp_kripto'] === 'ssl'
        ? PHPMailer::ENCRYPTION_SMTPS
        : PHPMailer::ENCRYPTION_STARTTLS;
    $mail->CharSet    = 'UTF-8';
    $mail->Timeout    = 20;

    $mail->setFrom($cfg['gonderen_mail'], $cfg['gonderen_ad']);
    foreach ($cfg['alicilar'] as $a) {
        $mail->addAddress($a[0], $a[1] ?? '');
    }
    $mail->addReplyTo($eposta, $ad);

    $mail->Subject = $tip . ' — ' . ($firma !== '' ? $firma : $ad);
    $mail->isHTML(true);
    $mail->Body =
        '<div style="font-family:Segoe UI,Arial,sans-serif;font-size:15px;line-height:1.6">'
        . '<p style="margin:0 0 14px;color:#5A6472">Web sitesi üzerinden yeni bir form gönderildi.</p>'
        . '<table style="border-collapse:collapse;margin-bottom:18px">' . $html . '</table>'
        . ($mesaj !== ''
            ? '<div style="border-left:3px solid #F4B740;padding:2px 0 2px 14px;color:#0B1220">'
              . nl2br(htmlspecialchars($mesaj, ENT_QUOTES, 'UTF-8')) . '</div>'
            : '')
        . '<p style="margin:22px 0 0;font-size:12px;color:#8A93A0">IP: '
        . htmlspecialchars($ip, ENT_QUOTES, 'UTF-8') . ' · ' . date('d.m.Y H:i') . '</p></div>';
    $mail->AltBody = $duz;

    $mail->send();

    // --- 6. Gönderene otomatik yanıt ---
    if (!empty($cfg['otomatik_yanit'])) {
        try {
            $yanit = new PHPMailer(true);
            $yanit->isSMTP();
            $yanit->Host       = $cfg['smtp_host'];
            $yanit->Port       = (int) $cfg['smtp_port'];
            $yanit->SMTPAuth   = true;
            $yanit->Username   = $cfg['smtp_user'];
            $yanit->Password   = $cfg['smtp_pass'];
            $yanit->SMTPSecure = $mail->SMTPSecure;
            $yanit->CharSet    = 'UTF-8';
            $yanit->Timeout    = 20;
            $yanit->setFrom($cfg['gonderen_mail'], $cfg['site_adi']);
            $yanit->addAddress($eposta, $ad);
            $yanit->addReplyTo($cfg['alicilar'][0][0], $cfg['site_adi']);
            $yanit->Subject = 'Talebiniz bize ulaştı — ' . $cfg['site_adi'];
            $yanit->isHTML(true);
            $yanit->Body =
                '<div style="font-family:Segoe UI,Arial,sans-serif;font-size:15px;line-height:1.65">'
                . '<p>Merhaba ' . htmlspecialchars($ad, ENT_QUOTES, 'UTF-8') . ',</p>'
                . '<p>Talebiniz bize ulaştı. Mesai saatleri içinde en geç birkaç saat içinde '
                . 'size dönüş yapacağız.</p>'
                . '<p>Acil bir durum varsa doğrudan arayabilirsiniz: <b>'
                . htmlspecialchars($cfg['telefon'], ENT_QUOTES, 'UTF-8') . '</b></p>'
                . '<p style="margin-top:24px;color:#5A6472">İyi çalışmalar,<br>'
                . htmlspecialchars($cfg['site_adi'], ENT_QUOTES, 'UTF-8') . '</p>'
                . '<hr style="border:0;border-top:1px solid #DCE3EB;margin:22px 0">'
                . '<p style="font-size:12px;color:#8A93A0">Bu e-posta '
                . htmlspecialchars($cfg['site_url'], ENT_QUOTES, 'UTF-8')
                . ' üzerinden gönderdiğiniz form nedeniyle otomatik oluşturulmuştur.</p></div>';
            $yanit->AltBody = "Merhaba $ad,\n\nTalebiniz bize ulaştı. Mesai saatleri içinde "
                . "dönüş yapacağız.\nAcil durumlar için: " . $cfg['telefon'] . "\n\n"
                . $cfg['site_adi'];
            $yanit->send();
        } catch (Exception $e) {
            // Otomatik yanıt gitmezse ana gönderimi başarısız sayma.
        }
    }

    @file_put_contents($log, $simdi . "\t" . $ip . "\t" . $tip . "\n", FILE_APPEND | LOCK_EX);
    yanit(true, 'Mesajınız bize ulaştı. En kısa sürede size dönüş yapacağız.');
} catch (Exception $e) {
    @file_put_contents($log, $simdi . "\tHATA\t" . $mail->ErrorInfo . "\n", FILE_APPEND | LOCK_EX);
    yanit(false, 'Mesaj gönderilemedi. Lütfen doğrudan info@acrbilgi.com adresine yazın '
        . 'ya da ' . $cfg['telefon'] . ' numarasından bize ulaşın.', 500);
}
