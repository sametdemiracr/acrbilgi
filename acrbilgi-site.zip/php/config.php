<?php
/**
 * ACR Bilgi — form gönderim ayarları
 *
 * GÜVENLİK NOTLARI
 * 1. Bu dosyayı asla e-postayla/sohbette paylaşmayın; uygulama şifresi içerir.
 * 2. Kurulumdan sonra Google Hesabınızda mevcut uygulama şifresini iptal edip
 *    yenisini oluşturun ve buraya yazın.
 * 3. php/ klasörüne web erişimi .htaccess ile kapatılmıştır.
 */

return [
    // --- SMTP (Gmail uygulama şifresi) ---
    'smtp_host'  => 'smtp.gmail.com',
    'smtp_port'  => 587,                 // 587 = STARTTLS. Çalışmazsa 465 + 'ssl' deneyin.
    'smtp_kripto' => 'tls',              // 'tls' veya 'ssl'
    'smtp_user'  => 'demir645@gmail.com',
    'smtp_pass'  => 'acxpshhotelmfzko',  // uygulama şifresi (boşluksuz)

    // --- Kimden / kime ---
    // Gönderen adresi SMTP hesabıyla aynı olmalı, aksi hâlde Gmail reddeder.
    'gonderen_mail' => 'demir645@gmail.com',
    'gonderen_ad'   => 'ACR Bilgi Web Sitesi',

    // Formlar bu adrese düşer. Birden fazla alıcı ekleyebilirsiniz.
    'alicilar' => [
        ['info@acrbilgi.com', 'ACR Bilgi'],
    ],

    // --- Davranış ---
    'otomatik_yanit' => true,   // gönderene "talebiniz alındı" e-postası gitsin mi
    'site_adi'       => 'ACR Bilgi Sistemleri',
    'site_url'       => 'https://www.acrbilgi.com',
    'telefon'        => '+90 530 969 40 10',

    // --- Kötüye kullanım koruması ---
    'saatlik_limit'  => 5,      // aynı IP'den saatte en fazla kaç gönderim
    'log_dosyasi'    => __DIR__ . '/gonderim.log',
];
